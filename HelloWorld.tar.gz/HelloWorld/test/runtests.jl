using HelloWorld
using Test

@testset "HelloWorld.jl" begin
    # Write your tests here.
end
