module HelloWorld

#Output message
greet() = print("Hello World!")

end
